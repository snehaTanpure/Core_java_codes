package collection_code;


import java.util.*;
public class Finding_common_Elements_two_list_String 
{
   public static void main(String x[])
   {
	    ArrayList al=new ArrayList();
	    
	    
   }
}
