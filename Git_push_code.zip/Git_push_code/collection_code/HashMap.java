package collection_code;

public record HashMap() {

}
