package collection_code;

/*
Q2. Remove Duplicate Names Using Set
Description: Given a list of names that may contain duplicates, use a HashSet to remove duplicate names and print the cleaned-up list.
*/


import java.util.*;
public class Remove_Duplicate_names_using_set 
{
   public static void main(String x[])
   {
	   HashSet h=new HashSet();
	   h.add("ABC");
	   h.add("MNO");
	   h.add("PQR");
	   h.add("LMN");
	   h.add("ABC");
	   
	   System.out.println(h);
	   
	   
	   
	   
	   
   }
	
}
