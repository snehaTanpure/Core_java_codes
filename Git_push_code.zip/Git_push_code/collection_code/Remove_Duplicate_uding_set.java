package collection_code;

/*
 * Q2. Remove Duplicates Using Set
Write a program that removes duplicate elements from a List using a HashSet and prints the cleaned list.

 */


import java.util.*;
public class Remove_Duplicate_uding_set 
{
	public static void main(String x[])
	{
	
		HashSet h=new HashSet();
		h.add(100);
		h.add(90);
		h.add(100);
		h.add(40);
		h.add(30);
		
		System.out.println(h);
		
	}

}
