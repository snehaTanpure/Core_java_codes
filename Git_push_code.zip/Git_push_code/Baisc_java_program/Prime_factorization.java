package Baisc_java_program;

/*
 * 29. Prime Factorization
Description: Write a program to perform prime factorization of a number n.
Input: n = 12


Output: 2 2 3



 */


public class Prime_factorization {

}
