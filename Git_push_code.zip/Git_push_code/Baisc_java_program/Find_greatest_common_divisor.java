package Baisc_java_program;


/*
 * 50. Find Greatest Common Divisor (GCD)
Description: Write a program to find the greatest common divisor (GCD) of two numbers.
Input: a = 12, b = 15


Output: 3

 */

import java.util.*;
public class Find_greatest_common_divisor
{
   public static void main (String x[])
   {
	   Scanner s=new Scanner(System.in);
	   System.out.println("Enter the first value");
	   int a=s.nextInt();
	   
	   
	   System.out.println("Enter the Secound value");
	   int b=s.nextInt();
	   
	   
	   
	   
	   
   }
}
