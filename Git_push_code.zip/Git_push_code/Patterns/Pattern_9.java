/*
Q12. Print the following pattern?
1111
2222
3333
4444
*/

public class Pattern_9
{
  public static void main(String x[])
  {
   
   
   for(int i=1;i<=4;i++)
   {
     for(int j=1;j<=4 ;j++)
	 {
		System.out.printf("%d",i);		
	 }
	 
	 System.out.println( );
   }
   
   
  }
}

/*
C:\Users\Tejas\Desktop\sneha documents\JAVA PROGRAM\Patterns>java Pattern_9
1111
2222
3333
4444
*/