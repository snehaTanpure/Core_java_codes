/*
Q16. Print the following pattern?
****
****
****
****
*/

public class Pattern_11
{
  public static void main(String x[])
  {
   
   
   for(int i=1;i<=4;i++)
   {
     for(int j=1;j<=4 ;j++)
	 {
		System.out.printf("*");		
	 }
	 
	 System.out.println( );
   }
   
   
  }
}

/*
C:\Users\Tejas\Desktop\sneha documents\JAVA PROGRAM\Patterns>java Pattern_11
****
****
****
****

*/